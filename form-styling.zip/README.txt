A Pen created at CodePen.io. You can find this one at https://codepen.io/ayanacampbell/pen/QbNyYE.

 https://dribbble.com/shots/1958400-Minimal-Login-and-Register-Forms/attachments/340070